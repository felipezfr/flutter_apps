import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import ColaboradoresSrv from '../../services/ColaboradoresSrv';


const ColaboradoresList = (props) => {

    console.log(props)

    const [colaboradores, setColaboradores] = useState([]);

    useEffect(() => {
        setColaboradores(props.colaboradores);
    });

    const statusBodyTemplate = (rowData) => {
        // console.log(rowData)
        return (
            <React.Fragment>
                <Button type="button" onClick={() => props.editarResponsavel(rowData.usuario._id)} className="p-button-text" >Atribuir como responsavel</Button>
                <Button type="button" onClick={() => props.excluirColaborador(rowData._id)} icon="pi pi-trash" className="p-button-text" />
            </React.Fragment>

        )
    }

    return (
        <div>
            <h4>Listagem de colaboradores do projeto: {props.projeto.titulo}</h4>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginInline: '30px' }}>
                <Button type="button" style={{ backgroundColor: 'darkgray', borderColor: 'black' }} onClick={() => props.inserirColaborador(props.projeto._id)}>Inserir colaborador para o projeto</Button>
                {/* <Button onClick={props.onClickAtualizar} type="button" icon="pi pi-refresh"  ></Button> */}
            </div>

            <DataTable value={colaboradores} paginator
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Mostrando de {first} a {last} de {totalRecords}" rows={5} rowsPerPageOptions={[5, 10, 20, 50, 500]}
                selectionMode='single'>

                {/* <Column field="index" header="Index"></Column> */}
                {/* <Column field="projeto.titulo" header="Titulo" sortable filter></Column> */}
                <Column field="usuario.nome" header="Colaboradores" sortable ></Column>
                {/* <Column field="dataInicio" header="Data Inicio" sortable filter></Column> */}
                {/* <Column field="dataTermino" header="Data Termino" sortable filter></Column> */}
                {/* <Column field="nomeDemandante" header="Nome Demandante" sortable filter></Column> */}
                <Column field="_id" header="Operações" body={statusBodyTemplate}></Column>
            </DataTable>
            <Button onClick={props.cancelar} type="button">Cancelar</Button>

        </div>
    )

}

export default ColaboradoresList