import React, { useState, useEffect } from 'react'
import { InputTextarea } from 'primereact/inputtextarea';
import { AutoComplete } from 'primereact/autocomplete';
import { Calendar } from 'primereact/calendar';

const ColaboradoresForm = (props) => {

    console.log(props)

    const [users, setUsers] = useState(null);
    const [selectedUser, setSelectedUser] = useState(null);
    const [filteredUser, setFilteredUser] = useState(null);
    const [colaboradores, setColaboradores] = useState([]);

    useEffect(() => {
        //setFilteredUser(props.usuarios) // ao inicializar execula método para atualizar
        setColaboradores(props.colaboradores)
        setUsers(props.usuarios)
    }, []);

    const handleSubmit = (event) => {
        props.salvar()
    }
    const handleInputChange = (event) => {
        const { name, value } = event.target
        props.setProjeto({ ...props.projeto, [name]: value })
    }


    const searchUser = (event) => {
        setTimeout(() => {
            let _filteredUsers;
            if (!event.query.trim().length) {
                _filteredUsers = [...users];
            }
            else {
                _filteredUsers = users.filter((user) => {
                    return user.nome.toLowerCase().startsWith(event.query.toLowerCase());
                });
            }

            setFilteredUser(_filteredUsers);
        }, 250);
    }

    return (
        <div>
            <h4>Inserir colaborador para o projeto: {props.projeto.titulo}</h4>

            <form onSubmit={handleSubmit} >

                <div className="p-field p-grid">
                    <label>Usuario</label>
                    <div className="p-col">
                        <AutoComplete dropdown field="nome" suggestions={filteredUser} name="usuario" completeMethod={searchUser}
                            value={selectedUser} onChange={(e) => {
                                props.setColaborador({ ...props.colaborador, usuario: e.value._id, projeto: props.projeto._id });
                                setSelectedUser(e.value);
                            }} />
                    </div>
                </div>
                <div className="form-group">
                    <button type="button" onClick={props.salvarColaborador}
                        className="btn btn-primary btn-sm">Adicionar</button>
                    <button type="button" onClick={props.cancelar}
                        className="btn btn-primary btn-sm">Cancelar</button>
                </div>
            </form>
        </div>
    )
}
export default ColaboradoresForm