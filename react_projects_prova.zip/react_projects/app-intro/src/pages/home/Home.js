import React, { useState, useEffect } from 'react'

const Home = () => {
    const [userName, setUserName] = useState(null);
    useEffect(() => {
        setUserName(sessionStorage.getItem('logado_nome'))
        console.log(userName)
    });
    return (
        <div className="App container pt-4">
            <h1>Bem vindo, {userName}.</h1>
        </div>
    )
}
export default Home