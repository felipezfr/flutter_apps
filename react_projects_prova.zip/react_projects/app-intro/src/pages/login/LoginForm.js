import React, { useRef, useState } from 'react'
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import UsuarioSrv from "../../services/UsuarioSrv"

const LoginForm = (props) => {
    const toastRef = useRef();
    const [credenciais, setCredenciais] = useState({ "email": "", "senha": "" })

    const handleInputChange = (event) => {
        const { name, value } = event.target
        setCredenciais({ ...credenciais, [name]: value })
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        UsuarioSrv.login(credenciais).then(response => {
            // o login foi com sucesso ... o tokem virá em response.data
            // console.log(response.data);
            let token = response.data

            if (token) {
                const jwt = require("jsonwebtoken")
                jwt.verify(token, process.env.REACT_APP_JWT_PRIV_KEY, function (err, decoded) {
                    if (err) {
                        toastRef.current.show({ severity: 'error', summary: "Token de autenticação invalido", life: 5000 });
                    }
                    else {
                        // tudo certo, guardar o token na sessionStorage para uso posterior
                        // tambem podemos guardar na session storge informacoers do payload para facilitar o uso
                        // por fim, atualizar o token no state da app para carregar a Home
                        console.log(decoded)
                        sessionStorage.setItem('token', token);
                        sessionStorage.setItem('logado_id', decoded._id);
                        sessionStorage.setItem('logado_nome', decoded.nome);
                        props.setToken(token);
                    }
                })

            }
            else {
                toastRef.current.show({ severity: 'error', summary: "Erro na autenticação", life: 5000 });
            }

        }).catch(({ response }) => {
            // aqui pegamos a mensagem do erro que vem em erro.data
            try {
                console.log(response.data);
                toastRef.current.show({ severity: 'error', summary: response.data, life: 5000 });
            } catch (error) {
                toastRef.current.show({ severity: 'error', summary: "Erro na conexão com a API", life: 5000 });
            }
        });
        return false;
    }

    return (
        <div className="container">

            <form onSubmit={handleSubmit} className="border border-5 rounded-3 mt-5" >
                <Toast ref={toastRef} />

                <div className="p-5">

                    <div className="form-group ">
                        <label htmlFor="email">Email</label>
                        <InputText id="email" type="email" name="email" className="form-control"
                            value={credenciais.email} onChange={handleInputChange} />
                    </div>
                    <div className="form-group">
                        <label htmlFor="senha">Senha</label>
                        <InputText id="senha" type="password" name="senha" className="form-control"
                            value={credenciais.senha} onChange={handleInputChange} />
                    </div>

                </div>

                <div style={{ textAlign: 'center' }}>
                    <Button icon="pi pi-save" type="submit" label="Login" className="p-button-sm" />
                </div>

            </form>
        </div>
    )
}
export default LoginForm
