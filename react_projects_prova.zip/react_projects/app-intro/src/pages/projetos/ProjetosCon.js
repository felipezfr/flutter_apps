import React, { useState, useEffect, useRef } from 'react';
import ProjetosList from './ProjetosList';
import ProjetosForm from './ProjetosForm';
import ColaboradoresList from '../colaboradores/ColaboradoresList';
import ColaboradoresForm from '../colaboradores/ColaboradoresForm';

import ProjetosSrv from '../../services/ProjetosSrv';
import UsuarioSrv from '../../services/UsuarioSrv';
import ColaboradoresSrv from '../../services/ColaboradoresSrv';

import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import { Toast } from 'primereact/toast';
import { confirmDialog } from 'primereact/confirmdialog';
// require("dotenv").config();

function ProjetosCon() {


  const toastRef = useRef(null);

  const [projetos, setProjetos] = useState([])
  const [usuarios, setUsuarios] = useState([]);
  const [colaboradores, setColaboradores] = useState([]);
  const [userID, setUserID] = useState(sessionStorage.getItem('logado_id'));

  useEffect(() => {
    onClickAtualizar(); // ao inicializar execula método para atualizar
    // setUserID(sessionStorage.getItem('logado_id'));
  }, []);

  const onClickAtualizar = () => {
    // console.log(userID)

    ProjetosSrv.listarID(userID)
      .then(response => {
        setProjetos(response.data);

        // console.log(response.data)

        toastRef.current.show({
          severity: 'success',
          summary: "Projetos atualizados",
          life: 3000
        });
      })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message,
          life: 3000
        });
      });

    UsuarioSrv.listar()
      .then(response => {
        setUsuarios(response.data);
      })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message,
          life: 3000
        });
      });

  }

  // operação inserir
  const initialState = { id: null, titulo: '', descricao: '', dataInicio: '', dataTermino: '', nomeDemandante: '', responsavel: '' }
  const [projeto, setProjeto] = useState(initialState)
  const [colaborador, setColaborador] = useState(initialState)
  const [responsavel, setResponsavel] = useState(null)
  const [editando, setEditando] = useState("")

  const inserir = () => {
    setProjeto(initialState);
    setEditando("ProjetosForm");
  }

  const salvar = () => {
    console.log(projeto)
    if (projeto._id == null) { // inclussão
      ProjetosSrv.incluir(projeto).then(response => {
        setEditando("");
        onClickAtualizar();
        toastRef.current.show({ severity: 'success', summary: "Salvou", life: 2000 });
      })
        .catch(e => {
          console.log(e)
          toastRef.current.show({ severity: 'error', summary: e.message, life: 4000 });
        });
    } else { // alteração
      ProjetosSrv.alterar(projeto).then(response => {
        setEditando("");
        onClickAtualizar();
        toastRef.current.show({ severity: 'success', summary: "Salvou", life: 2000 });
      })
        .catch(e => {
          toastRef.current.show({ severity: 'error', summary: e.message, life: 4000 });
        });
    }
  }

  const salvarColaborador = () => {
    console.log(colaborador)

    ColaboradoresSrv.incluir(colaborador).then(response => {
      setEditando("ColaboradoresList");
      colaboradoresList(projeto._id);
      toastRef.current.show({ severity: 'success', summary: "Salvou", life: 2000 });
    })
      .catch(e => {
        console.log(e)
        toastRef.current.show({ severity: 'error', summary: e.message, life: 4000 });
      });

  }


  const excluir = (_id) => {
    confirmDialog({
      message: 'Confirma a exclusão?',
      header: 'Confirmação',
      icon: 'pi pi-question',
      acceptLabel: 'Sim',
      rejectLabel: 'Não',
      acceptClassName: 'p-button-danger',
      accept: () => excluirConfirm(_id)
    });
  }

  const excluirConfirm = (_id) => {
    ProjetosSrv.excluir(_id).then(response => {
      onClickAtualizar();
      toastRef.current.show({
        severity: 'success',
        summary: "Excluído", life: 2000
      });
    })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message, life: 4000
        });
      });
  }

  const excluirColaborador = (_id) => {
    confirmDialog({
      message: 'Tem certeza que deseja excluir o colaborador?',
      header: 'Confirmação',
      icon: 'pi pi-question',
      acceptLabel: 'Sim',
      rejectLabel: 'Não',
      acceptClassName: 'p-button-danger',
      accept: () => excluirColaboradorConfirm(_id)
    });
  }

  const excluirColaboradorConfirm = (_id) => {
    ColaboradoresSrv.excluir(_id).then(response => {
      colaboradoresList(projeto._id);
      toastRef.current.show({
        severity: 'success',
        summary: "Excluído", life: 2000
      });
    })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message, life: 4000
        });
      });
  }

  const cancelar = () => {
    console.log('Cancelou ...');
    setEditando("");
  }

  const editar = (id) => {
    setProjeto(projetos.filter((projeto) => projeto._id === id)[0]);
    setEditando("ProjetosForm");

  }

  const colaboradoresList = (id) => {

    ColaboradoresSrv.listarID(id)
      .then(response => {
        setColaboradores(response.data);
        // console.log(response.data)
        toastRef.current.show({
          severity: 'success',
          summary: "Colaboradores atualizados",
          life: 3000
        });
      })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message,
          life: 3000
        });
      });
    setProjeto(projetos.filter((projeto) => projeto._id === id)[0]);
    setEditando("ColaboradoresList");
  }

  const inserirColaborador = (id) => {
    setProjeto(projetos.filter((projeto) => projeto._id === id)[0]);
    setEditando("ColaboradoresForm");
  }

  const editarResponsavel = (id) => {

    console.log(projeto)
    setProjeto({ ...projeto, responsavel: id })

    ProjetosSrv.alterar({ _id: projeto._id, responsavel: id })
      .then(response => {        
        
        onClickAtualizar();
        setEditando("");

        toastRef.current.show({
          severity: 'success',
          summary: "Responsavel atualizado",
          life: 3000
        });
      })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message,
          life: 3000
        });
      });
  }

  if (editando === "") {
    return (
      <div className="container App">
        <Toast ref={toastRef} />
        <ProjetosList projetos={projetos} colaboradores={colaboradoresList} onClickAtualizar={onClickAtualizar}
          inserir={inserir} editar={editar} excluir={excluir} />
      </div>
    );
  } else if (editando === "ProjetosForm") {
    return (
      <div className="container App">
        <Toast ref={toastRef} />
        <ProjetosForm projeto={projeto} setProjeto={setProjeto}
          salvar={salvar} cancelar={cancelar} usuarios={usuarios} />
      </div>
    );
  } else if (editando === "ColaboradoresList") {
    return (
      <div className="container App">
        <Toast ref={toastRef} />
        <ColaboradoresList salvar={salvar} cancelar={cancelar} usuarios={usuarios}
          projeto={projeto} colaboradores={colaboradores} excluirColaborador={excluirColaborador} inserirColaborador={inserirColaborador} editarResponsavel={editarResponsavel} />
      </div>
    );
  }
  else if (editando === "ColaboradoresForm") {
    return (
      <div className="container App">
        <Toast ref={toastRef} />
        <ColaboradoresForm salvarColaborador={salvarColaborador} cancelar={cancelar} usuarios={usuarios}
          projeto={projeto} excluirColaborador={excluirColaborador} setColaborador={setColaborador} />
      </div>
    );
  }


}

export default ProjetosCon;