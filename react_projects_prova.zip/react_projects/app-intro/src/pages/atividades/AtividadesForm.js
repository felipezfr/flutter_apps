import React, { useState, useEffect } from 'react'
import { InputTextarea } from 'primereact/inputtextarea';
import { AutoComplete } from 'primereact/autocomplete';
import { Calendar } from 'primereact/calendar';

const AtividadeForm = (props) => {

    console.log(props)

    const [users, setUsers] = useState(null);
    const [projetos, setProjetos] = useState(null);
    const [selectedUser, setSelectedUser] = useState(null);
    const [filteredUser, setFilteredUser] = useState(null);
    const [selectedProjeto, setSelectedProjeto] = useState(null);
    const [filteredProjeto, setFilteredProjeto] = useState(null);

    const handleSubmit = (event) => {
        props.salvar()
    }
    const handleInputChange = (event) => {
        const { name, value } = event.target
        props.setAtividade({ ...props.atividade, [name]: value })
    }

    useEffect(() => {
        //setFilteredUser(props.usuarios) // ao inicializar execula método para atualizar
        setSelectedUser(props.atividade.responsavel)
        setSelectedProjeto(props.atividade.projeto)
        setUsers(props.usuarios)
        setProjetos(props.projetos)
    }, []);

    const searchUser = (event) => {
        console.log(event)
        setTimeout(() => {
            let _filteredUsers;
            if (!event.query.trim().length) {
                _filteredUsers = [...users];
            }
            else {
                _filteredUsers = users.filter((user) => {
                    return user.nome.toLowerCase().startsWith(event.query.toLowerCase());
                });
            }

            setFilteredUser(_filteredUsers);
        }, 250);
    }

    const searchProjeto = (event) => {
        setTimeout(() => {
            console.log(projetos)
            let _filteredProjetos;
            if (!event.query.trim().length) {
                _filteredProjetos = [...projetos];
            }
            else {
                _filteredProjetos = projetos.filter((user) => {
                    return projetos.nome.toLowerCase().startsWith(event.query.toLowerCase());
                });
            }

            setFilteredProjeto(_filteredProjetos);
        }, 250);
    }

    return (
        <form onSubmit={handleSubmit} >
            <div className="p-field p-grid">
                <label htmlFor="title" className="p-col-fixed" style={{ width: '100px' }} >Titulo</label>
                <div className="p-col">
                    <InputTextarea type="text" id="title" name="titulo"
                        value={props.atividade.titulo} onChange={handleInputChange} />
                </div>
            </div>
            <div className="p-field p-grid">
                <label className="p-col-fixed" style={{ width: '100px' }} >Descrição</label>
                <div className="p-col">
                    <InputTextarea type="text" name="descricao"
                        value={props.atividade.descricao} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Data Inicio</label>
                <div className="p-col">
                    <Calendar name="dataInicio" value={new Date(props.atividade.dataInicio)} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Data Termino</label>
                <div className="p-col">
                    <Calendar name="dataTermino" value={new Date(props.atividade.dataTermino)} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Responsavel</label>
                <div className="p-col">
                    <AutoComplete dropdown field="nome" suggestions={filteredUser} name="responsavel" completeMethod={searchUser}
                        value={selectedUser} onChange={(e) => {
                            props.setAtividade({ ...props.atividade, responsavel: e.value._id });
                            setSelectedUser(e.value);
                        }} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Projeto</label>
                <div className="p-col">
                    <AutoComplete dropdown field="titulo" suggestions={filteredProjeto} name="projeto" completeMethod={searchProjeto}
                        value={selectedProjeto} onChange={(e) => {
                            props.setAtividade({ ...props.atividade, projeto: e.value._id });
                            setSelectedProjeto(e.value);
                        }} />
                </div>
            </div>
            <div class="form-group">
                <button type="button" onClick={props.salvar}
                    className="btn btn-primary btn-sm">Salvar</button>
                <button type="button" onClick={props.cancelar}
                    className="btn btn-primary btn-sm">Cancelar</button>
            </div>
        </form>
    )
}
export default AtividadeForm