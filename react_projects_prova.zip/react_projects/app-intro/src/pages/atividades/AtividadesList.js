import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import React from 'react';


const AtividadeList = (props) => {
    // console.log(props)
    const statusBodyTemplate = (rowData) => {
        return (
            <React.Fragment>
                <Button type="button" onClick={() => props.editar(rowData._id)} icon="pi pi-pencil" className="p-button-text" />
                <Button type="button" onClick={() => props.excluir(rowData._id)} icon="pi pi-times" className="p-button-text" />
            </React.Fragment>
            
        )
    }

    return (
        <div>
            <h4>Listagem de atividades</h4>
            {/* <button type="button" class="btn btn-primary btn-sm" onClick={props.onClickAtualizar} >Atualizar Lista</button> */}
            {/* <button type="button" className="btn btn-primary btn-sm" onClick={props.inserir}>Cadastrar Projeto</button> */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginInline: '30px' }}>
                <Button type="button" style={{ backgroundColor: 'darkgray', borderColor: 'black' }} onClick={props.inserir}>Cadastrar Atividade</Button>
                <Button onClick={props.onClickAtualizar} type="button" icon="pi pi-refresh"  ></Button>
            </div>

            <DataTable value={props.atividades} paginator
                paginatorTemplate="CurrentPageReport FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                currentPageReportTemplate="Mostrando de {first} a {last} de {totalRecords}" rows={5} rowsPerPageOptions={[5, 10, 20, 50, 500]}
                selectionMode='single'>

                {/* <Column field="index" header="Index"></Column> */}
                <Column field="titulo" header="Titulo" sortable></Column>
                <Column field="descricao" header="Descrição" sortable></Column>
                <Column field="dataInicio" header="Data Inicio" sortable></Column>
                <Column field="dataTermino" header="Data Termino" sortable></Column>
                <Column field="projeto.titulo" header="Projeto" sortable></Column>
                <Column field="_id" header="Operações" body={statusBodyTemplate}></Column>
            </DataTable>

            {/* <table className="table">
            <thead>
                <tr> <th>Index</th><th>Titulo</th><th>Descrição</th><th>Data Inicio</th><th>Data Termino</th><th>Nome Demandante</th> </tr>
            </thead>
            <tbody>
                {props.atividades.length > 0 ? (props.atividades.map((o, index) => (
                    <tr key={index}>
                        <td>{index}</td>
                        <td>{o.titulo}</td>
                        <td>{o.descricao}</td>
                        <td>{o.dataInicio}</td>
                        <td>{o.dataTermino}</td>
                        <td>{o.nomeDemandante}</td>
                        <td>
                            <button onClick={() => props.editar(o._id)} class="btn btn-success btn-sm" type="button">Editar</button>
                            <button onClick={() => props.excluir(o._id)} class="btn btn-danger btn-sm" type="button">Excluir</button>
                        </td>
                    </tr>
                ))) : (
                    <tr>
                        <td colSpan={3}>Nenhum projeto.</td>
                    </tr>
                )}
            </tbody>
        </table> */}
        </div>
    )

}

export default AtividadeList