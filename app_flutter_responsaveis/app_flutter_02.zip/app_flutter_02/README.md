COMANDOS IMPORTANTES PARA O APP

#para liberar acesso a porta 3000 pelo emulador
    adb reverse tcp:3000 tcp:3000

#Para limpar e conseguir zipar
    flutter clean