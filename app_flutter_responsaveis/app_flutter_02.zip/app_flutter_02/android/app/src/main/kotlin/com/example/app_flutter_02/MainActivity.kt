package com.example.app_flutter_02

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
