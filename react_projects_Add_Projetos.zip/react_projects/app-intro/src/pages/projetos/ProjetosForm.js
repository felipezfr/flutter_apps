import React, { useState, useEffect } from 'react'
import { InputTextarea } from 'primereact/inputtextarea';
import { AutoComplete } from 'primereact/autocomplete';

import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { addLocale } from 'primereact/api';

const ProjetoForm = (props) => {

    console.log(props)

    const [users, setUsers] = useState(null);
    const [selectedUser, setSelectedUser] = useState(null);
    const [filteredUser, setFilteredUser] = useState(null);

    const handleSubmit = (event) => {
        props.salvar()
    }
    const handleInputChange = (event) => {
        const { name, value } = event.target
        props.setProjeto({ ...props.projeto, [name]: value })
    }

    useEffect(() => {
        //setFilteredUser(props.usuarios) // ao inicializar execula método para atualizar
        setSelectedUser(props.projeto.responsavel)
        setUsers(props.usuarios)
    }, []);

    const searchUser = (event) => {
        setTimeout(() => {
            let _filteredUsers;
            if (!event.query.trim().length) {
                _filteredUsers = [...users];
            }
            else {
                _filteredUsers = users.filter((user) => {
                    return user.nome.toLowerCase().startsWith(event.query.toLowerCase());
                });
            }

            setFilteredUser(_filteredUsers);
        }, 250);
    }

    return (
        <form onSubmit={handleSubmit} >
            <div className="p-field p-grid">
                <label htmlFor="title" className="p-col-fixed" style={{ width: '100px' }} >Titulo</label>
                <div className="p-col">
                    <InputTextarea type="text" id="title" name="titulo"
                        value={props.projeto.titulo} onChange={handleInputChange} />
                </div>
            </div>
            <div className="p-field p-grid">
                <label className="p-col-fixed" style={{ width: '100px' }} >Descrição</label>
                <div className="p-col">
                    <InputTextarea type="text" name="descricao"
                        value={props.projeto.descricao} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Data Inicio</label>
                <div className="p-col">
                    <Calendar name="dataInicio" value={props.projeto.dataInicio} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Data Termino</label>
                <div className="p-col">
                    <Calendar  name="dataTermino" value={props.projeto.dataTermino} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Nome Demandante</label>
                <div className="p-col">
                    <InputTextarea class="form-control" type="text" name="nomeDemandante"
                        value={props.projeto.nomeDemandante} onChange={handleInputChange} />
                </div>
            </div>
            <div class="p-field p-grid">
                <label>Responsavel</label>
                <div className="p-col">
                    <AutoComplete dropdown field="nome" suggestions={filteredUser} name="responsavel" completeMethod={searchUser}
                        value={selectedUser} onChange={(e) => {
                            props.setProjeto({ ...props.projeto, responsavel: e.value._id });
                            setSelectedUser(e.value);
                        }} />
                </div>
            </div>
            <div class="form-group">
                <button type="button" onClick={props.salvar}
                    className="btn btn-primary btn-sm">Salvar</button>
                <button type="button" onClick={props.cancelar}
                    className="btn btn-primary btn-sm">Cancelar</button>
            </div>
        </form>
    )
}
export default ProjetoForm