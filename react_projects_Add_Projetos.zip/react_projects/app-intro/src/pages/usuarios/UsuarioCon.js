
import React, { useState, useEffect, useRef } from 'react';
import UsuarioList from './UsuariosList';
import UsuarioForm from './UsuarioForm';
import UsuarioSrv from '../../services/UsuarioSrv';
//Prime React
import PrimeReact from 'primereact/api';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import { Toast } from 'primereact/toast';
import { confirmDialog } from 'primereact/confirmdialog';

// require("dotenv").config();

function UsuarioCon() {

  const toastRef = useRef(null);
  

  const [usuarios, setUsuarios] = useState([])
  useEffect(() => {
    onClickAtualizar(); // ao inicializar execula método para atualizar
  }, []);

  const onClickAtualizar = () => {
    UsuarioSrv.listar().then(response => {
      setUsuarios(response.data);
      toastRef.current.show({
        severity: 'success',
        summary: "Usuários atualizados",
        life: 3000
      });
    })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message,
          life: 3000
        });
      });
  }

  // operação inserir
  const initialState = { id: null, nome: '', email: '', celular: '' }
  const [usuario, setUsuario] = useState(initialState)
  const [editando, setEditando] = useState(false)

  const inserir = () => {
    setUsuario(initialState);
    setEditando(true);
  }

  const salvar = () => {
    if (usuario._id == null) { // inclussão
      UsuarioSrv.incluir(usuario).then(response => {
        setEditando(false);
        onClickAtualizar();
        toastRef.current.show({ severity: 'success', summary: "Salvou", life: 2000 });
      })
        .catch(e => {
          toastRef.current.show({ severity: 'error', summary: e.message, life: 4000 });
        });
    } else { // alteração
      UsuarioSrv.alterar(usuario).then(response => {
        setEditando(false);
        onClickAtualizar();
        toastRef.current.show({ severity: 'success', summary: "Salvou", life: 2000 });
      })
        .catch(e => {
          toastRef.current.show({ severity: 'error', summary: e.message, life: 4000 });
        });
    }
  }

  const excluir = (_id) => {
    confirmDialog({
      message: 'Confirma a exclusão?',
      header: 'Confirmação',
      icon: 'pi pi-question',
      acceptLabel: 'Sim',
      rejectLabel: 'Não',
      acceptClassName: 'p-button-danger',
      accept: () => excluirConfirm(_id)
    });
  }

  const excluirConfirm = (_id) => {
    UsuarioSrv.excluir(_id).then(response => {
      onClickAtualizar();
      toastRef.current.show({
        severity: 'success',
        summary: "Excluído", life: 2000
      });
    })
      .catch(e => {
        toastRef.current.show({
          severity: 'error',
          summary: e.message, life: 4000
        });
      });
  }

  const cancelar = () => {
    console.log('Cancelou ...');
    setEditando(false);
  }

  const editar = (id) => {
    setUsuario(usuarios.filter((usuario) => usuario._id == id)[0]);
    setEditando(true);

  }


  if (!editando) {
    return (
      <div className="App">
        <Toast ref={toastRef} />
        <UsuarioList usuarios={usuarios} onClickAtualizar={onClickAtualizar}
          inserir={inserir} editar={editar} excluir={excluir} />
      </div>
    );
  } else {
    return (
      <div className="App">
        <Toast ref={toastRef} />
        <UsuarioForm usuario={usuario} setUsuario={setUsuario}
          salvar={salvar} cancelar={cancelar} />
      </div>
    );

  }


}

export default UsuarioCon;