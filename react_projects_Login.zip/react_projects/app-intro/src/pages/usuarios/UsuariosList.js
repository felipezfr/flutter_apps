import 'primeicons/primeicons.css';
import { Button } from 'primereact/button';

const UsuarioList = (props) => {

    

    return (

        <div>
            <h4>Listagem de usuários</h4>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginInline: '30px' }}>
                <Button type="button" style={{backgroundColor: 'darkgray', borderColor : 'black'}}  onClick={props.inserir}>Inserir Usuário</Button>
                <Button onClick={props.onClickAtualizar} type="button" icon="pi pi-refresh"  ></Button>
            </div>
            <table className="table">
                <thead>
                    <tr> <th>Index</th><th>Nome</th><th>Email</th><th>Celular</th><th>Operações</th> </tr>
                </thead>
                <tbody>
                    {props.usuarios.length > 0 ? (props.usuarios.map((o, index) => (
                        <tr key={index}>
                            <td>{index}</td>
                            <td>{o.nome}</td>
                            <td>{o.email}</td>
                            <td>{o.celular}</td>
                            <td>
                                <Button onClick={() => props.definirSenha(o._id)} type="button">Definir Senha</Button>
                                <Button onClick={() => props.editar(o._id)} icon="pi pi-pencil" className="p-button-text" type="button"></Button>
                                <Button onClick={() => props.excluir(o._id)} icon="pi pi-trash" className="p-button-text" type="button"></Button>
                            </td>
                        </tr>
                    ))) : (
                        <tr>
                            <td colSpan={3}>Nenhum usuário.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>

    )
}

export default UsuarioList